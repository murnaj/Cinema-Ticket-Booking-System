package com.company;

public class Seat {

    private int seatNumber;
    private boolean isReserved;

    public Seat(int seatNumber, boolean isReserved) throws Exception{
        setSeatNumber(seatNumber);
        setisReserved(isReserved);

    }

    public int getSeatNumber() {
        return seatNumber;
    }

    public void setSeatNumber(int seatNumber) {
        this.seatNumber = seatNumber;
    }

    public boolean getisReserved() {
        return isReserved;
    }

    public void setisReserved(boolean reserved) {
        isReserved = reserved;
    }

    public void reserve(){   //for reserve
        isReserved = true;
    }

    public void unreserve(){  //for unreserve
        isReserved = false;
    }

}