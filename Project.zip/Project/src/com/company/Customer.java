package com.company;

public class Customer {

    private  int id;
    private String name;
    private String phoneNumber;
    private String city;


    public Customer(int id)throws Exception {
        setId(id);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void printCustomer(){
        System.out.println("Name: "+name);
        System.out.println("Phone Number: "+phoneNumber);
        System.out.println("City: "+city);
    }

}