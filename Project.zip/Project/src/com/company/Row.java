package com.company;
import java.util.ArrayList;

public class Row {

    private ArrayList<Seat> seats;
    private int rowNumber;
    private int rowClass;
    private int seatCount;

    public Row(int rowClass,int seatCount,int rowNumber) throws Exception{
        setRowNumber(rowNumber);
        setSeatCount(seatCount);
        setRowClass(rowClass);
        seats = new ArrayList<Seat>();
        createSeats(this.seatCount);  //it will create seats

    }

    public void createSeats(int seatCount) throws Exception {
        for (int i =1;i<=seatCount;i++){
            seats.add(new Seat(i, false)); //when we create seat it is not reserved at that time
        }
    }

    public int getRowNumber() {
        return rowNumber;
    }

    public int getRowClass() {
        return rowClass;
    }

    public int getSeatCount() {
        return seatCount;
    }

    public void setSeatCount(int seatCount) {
        this.seatCount = seatCount;
    }

    public void setRowNumber(int rowNumber) {
        this.rowNumber = rowNumber;
    }

    public void setRowClass(int rowClass) {
        this.rowClass = rowClass;
    }

    public ArrayList<Seat> getSeats() {
        return seats;
    }

}