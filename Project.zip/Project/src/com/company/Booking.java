package com.company;

public class Booking {

    private double price;
    private Customer customer;
    private Movie movie;
    private int rowNumber;
    private int seatNumber;

    public Booking(Customer customer,Movie movie)throws Exception {
        setCustomer(customer);
        setMovie(movie);

    }

    public double getPrice() {
        if (movie.getTheatre().getRows().get(rowNumber).getRowClass() ==1){
            return price += 800;
        }else {
            return price +=500;
        }
    }


    public void setRowNumber(int rowNumber) {
        this.rowNumber = rowNumber;
    }

    public void setSeatNumber(int seatNumber) {
        this.seatNumber = seatNumber;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public void setMovie(Movie movie) {
        this.movie = movie;
    }

    public boolean reserveSeat(int selectedRow, int selectedSeat){
        if (movie.getTheatre().getRows().get(selectedRow).getSeats().get(selectedSeat).getisReserved()) {
            return false;       //if a seat is already reserve it will return false else it will reserve seat
        } else {
            movie.getTheatre().getRows().get(selectedRow).getSeats().get(selectedSeat).reserve();
            setRowNumber(selectedRow);
            setSeatNumber(selectedSeat);
            return true;
        }
    }

    public boolean unreserveSeat(){
        movie.getTheatre().getRows().get(rowNumber).getSeats().get(seatNumber).unreserve();
        return true;
    }

    public Customer getCustomer() {
        return customer;
    }

}
