package com.company;

public class AlitaBattleAngel extends Movie {

    public AlitaBattleAngel(int movieNumber, String movieName, String movieDate, Theatre theatre) throws Exception {
        super(movieNumber,movieName,movieDate,theatre);
    }


    @Override
    public String minutes() {
        return "2 hour 2 minutes";
    }

    @Override
    public String plot() {
        return "A deactivated cyborg's revived, but can't remember anything of her past and goes on a quest to find out who she is.";
    }

}
