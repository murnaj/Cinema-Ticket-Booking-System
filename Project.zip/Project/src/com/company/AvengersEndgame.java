package com.company;

public class AvengersEndgame extends Movie {

    public AvengersEndgame(int movieNumber,String movieName,String movieDate,Theatre theatre) throws Exception {
        super(movieNumber,movieName,movieDate,theatre);
    }


    @Override
    public String minutes() {
        return "3 hour 1 minutes";
    }

    @Override
    public String plot() {
        return "After the devastating events of Avengers: Infinity War (2018), the universe is in ruins. With the help of remaining allies, the Avengers assemble once more in order to reverse Thanos' actions and restore balance to the universe.";
    }

}