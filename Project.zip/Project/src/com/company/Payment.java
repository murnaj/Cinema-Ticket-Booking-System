package com.company;

public class Payment {
    private double amount;

    public Payment(){
        this.amount = 0.0;
    }
    public Payment(double PaymentAmount){
        this.amount = PaymentAmount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public double getAmount() {
        return amount;
    }

    public void paymentDetails(){
        System.out.println("The payment amount is: "+amount);
    }

}

