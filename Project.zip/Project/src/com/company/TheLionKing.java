package com.company;

public class TheLionKing extends Movie {

    public TheLionKing(int movieNumber, String movieName, String movieDate, Theatre theatre) throws Exception {
        super(movieNumber,movieName,movieDate,theatre);
    }


    @Override
    public String minutes() {
        return "1 hour 58 minutes";
    }

    @Override
    public String plot() {
        return "After the murder of his father, a young lion prince flees his kingdom only to learn the true meaning of responsibility and bravery.";
    }

}