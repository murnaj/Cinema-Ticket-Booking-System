package com.company;

public class Aladdin extends Movie{

    public Aladdin(int movieNumber, String movieName, String movieDate, Theatre theatre) throws Exception {
        super(movieNumber,movieName,movieDate,theatre);
    }


    @Override
    public String minutes() {
        return "2 hour 8 minutes";
    }

    @Override
    public String plot() {
        return "A kind-hearted street urchin and a power-hungry Grand Vizier vie for a magic lamp that has the power to make their deepest wishes come true";
    }

}