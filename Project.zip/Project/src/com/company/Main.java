package com.company;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws Exception {
        // write your code here
        int option = 0;
        ArrayList<Movie> movies = new ArrayList<Movie>();
        ArrayList<Theatre> theatres = new ArrayList<Theatre>();
        ArrayList<Booking> bookings = new ArrayList<Booking>();
        ArrayList<Customer> customers = new ArrayList<Customer>();
        Scanner select = new Scanner(System.in);    // for selecting
        Scanner choice = new Scanner(System.in);       // for choice

        // Objects
        Theatre theatre = new Theatre(1, "Main theater");
        theatre.createRows(1, 10, 7);
        theatres.add(theatre);
        movies.add(new TheLionKing(1, "The Lion King","2-7-2020",theatre));
        System.out.println("\n");
        Theatre theatre1 = new Theatre(2, "Nueplex");
        theatre.createRows(1, 10, 7);
        theatres.add(theatre1);
        movies.add(new AvengersEndgame(2, "AvengersEndgame", "22-12-2020",theatre));

        Theatre theatre2 = new Theatre(3, "Cineplex");
        theatre.createRows(1, 10, 7);
        theatres.add(theatre2);
        movies.add(new AlitaBattleAngel(3, "Alita Battle Angels", "22-6-2020", theatre));

        do {
            System.out.println("------------------------------------");
            System.out.println(":Cinema Booking System:");
            System.out.println("------------------------------------\n");
            System.out.println("Please Enter 1 to Select a Theatre");
            System.out.println("Please Enter 2 to Display Shows");
            System.out.println("Please Enter 3 to Make Booking");
            System.out.println("Please Enter 4 to Cancel Booking");
            System.out.println("Please Enter 5 to Exit\n");

            System.out.print("Enter Option: ");
            option = select.nextInt();       //user select an option

            if (option == 1) {
                System.out.println("Select a THEATRE ");
                System.out.println("-------------------------\n");
                System.out.println("1. Main Theatre\n2. Nueplex\n3. Cineplex");
                String theatreName = choice.nextLine();
                System.out.print("Enter a number for the theatre: \n");
                int theatreNumber = choice.nextInt();

                Theatre theatre3 = new Theatre(theatreNumber,theatreName);
                theatre.createRows(1, 10, 7);
                theatres.add(theatre3);
                movies.add(new Aladdin(4, "Aladdin", "24-12-2020", theatre));
            }

            if(option==2)
            {
                System.out.println("Display Movies");
                System.out.println("-------------------------\n");
                for (int i = 0; i < movies.size(); i++)
                {
                    int movieNumber = i+1;            //array starts from 0 so i+1 = 0+1 = 1 shows first movie
                    System.out.println("Movie Number: " + movieNumber);
                    System.out.println("Movie Name: " + movies.get(i).getMovieName());
                    System.out.println("Movie Date: " + movies.get(i).getMovieDate());
                    System.out.println("Movie Minutes: "+movies.get(i).minutes());
                    System.out.println("Movie Plot: "+movies.get(i).plot());
                    System.out.println("\n");
                }
                System.out.println(" Movie List End.\n");
            }

            if(option==3) {
                System.out.println("PLEASE MAKE BOOKING ");
                System.out.println("-------------------------\n");
                Random rnd = new Random();     //object for random
                int customerId = rnd.nextInt(999);  //its generates a random number
                Customer customer = new Customer(customerId);
                customers.add(customer);
                for (int i = 0; i < movies.size(); i++) {
                    int movieNumber = i + 1;
                    System.out.println("Movie Number: " + movieNumber);
                    System.out.println("Movie Name:   " + movies.get(i).getMovieName());
                    System.out.println("Movie Date:   " + movies.get(i).getMovieDate());
                    System.out.print("\n");
                }

                System.out.println("-------------------------");
                System.out.print("Please Enter the movie number: ");
                int movieNumber = choice.nextInt();
                int repeat = 0;  //loop
                System.out.println();
                do {

                    System.out.print("Please Enter the row: ");
                    int selectedRow = choice.nextInt();
                    System.out.print("Please Enter the seat: ");
                    int selectedSeat = choice.nextInt();
                    System.out.println();
                    Booking booking = new Booking(customer, movies.get(movieNumber-1 )); //user sees movie from number 1 so it will -1 so it shows first movie which is on index 0 in array
                    Booking booking1 = new Booking(customer, movies.get(movieNumber-1));

                    if (booking.reserveSeat(selectedRow-1, selectedSeat-1)) {  //user select row and seat
                        bookings.add(booking);
                        System.out.println("The seat is now reserved for you."); //if user selected seat and row is available it reserved the seat
                    } else {
                        System.out.println("Sorry the seat is already reserved."); //else it says the seat is already reserved
                    }

                    System.out.println();
                    System.out.print("Please Enter 1 to reserve another seat or 2 to check out: ");
                    repeat = choice.nextInt(); //for repeat the process if user enter 1 so process will repeat else it checkout
                }
                while (repeat == 1);  //repeat same process
                System.out.println();
                System.out.println("Your Bill Amount:");
                System.out.println("-------------------------");
                int totalCost = 0;

                for (Booking booking : bookings) //it sees every booking and
                {
                    if (booking.getCustomer().getId() == customer.getId()) //then it see booking customer id and match it with customer id which assign to customer
                    {
                        totalCost += booking.getPrice(); //and if it match then it return total costs
                    }
                }
                System.out.println("Costumer ID: " + customer.getId());
                System.out.println("Total costs: " + totalCost + " Rupees");
                System.out.println();
            }

            if(option==4)
            {
                System.out.println("CANCEL BOOKING ");
                System.out.println("-------------------------\n");
                System.out.print("Please Enter the costumer id: ");
                int customerId = choice.nextInt();  //get customer id
                for (Customer customer : customers) {
                    if (customer.getId() == customerId)  // match customer ids then
                    {
                        for(Booking booking : bookings)  //then it check bookings
                        {
                            if (booking.getCustomer().getId() == customer.getId()) //and if customer id matches
                            {
                                if (booking.unreserveSeat()){  //it unreserve the seat
                                    System.out.println("Your reservation has been canceled!");
                                    break;
                                }
                            }
                        }
                    }
                }
                System.out.println();
            }


            if(option==5)
            {
                System.exit(0);    //for exit
            }

        }while(true);        //if user not enter option 5 it will true till user not exit
    }

}

