package com.company;
import java.util.ArrayList;

public class Theatre {

    private int theatreNumber;
    private String description;
    private int rowCount;
    private ArrayList<Row> rows;

    public Theatre(int theatreNumber, String description) throws Exception {
        setTheatreNumber(theatreNumber);
        setDescription(description);
        rows = new ArrayList<Row>();
    }


    public void createRows(int rowClass, int seatCount, int rowCount) throws Exception {
        for (int i = 1; i <= rowCount; i++) {
            rows.add(new Row(rowClass, seatCount, i));
        }
        this.rowCount += rowCount;
    }

    public ArrayList<Row> getRows() {
        return rows;
    }

    public int getTheatreNumber() {
        return theatreNumber;
    }

    public String getDescription() {
        return description;
    }

    public void setTheatreNumber(int theatreNumber) {
        this.theatreNumber = theatreNumber;
    }

    public void setDescription(String description) {
        this.description = description;

    }
}