package com.company;
import java.util.ArrayList;


public abstract class Movie {
    public int movieNumber;
    public String movieName;
    private String movieDate;
    private Theatre theatre;
    private ArrayList<Seat> seats;

    public Movie(int movieNumber,String movieName,String movieDate,Theatre theatre)throws Exception{
        setMovieNumber(movieNumber);
        setMovieName(movieName);
        setMovieDate(movieDate);
        setTheatre(theatre);
    }

    public void LoadSeats(){
        for (Row row : theatre.getRows()){  //theatre rows in which movie is running
            for (Seat seat : row.getSeats()){   // their row seats
                seats.add(seat);
            }
        }
    }

    public void setMovieNumber(int movieNumber) {
        this.movieNumber = movieNumber;
    }

    public int getMovieNumber() {
        return movieNumber;
    }

    public String getMovieName() {
        return movieName;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    public void setShowName(String movieName) {
        this.movieName = movieName;
    }

    public String getMovieDate() {
        return movieDate;
    }

    public void setMovieDate(String movieDate) {
        this.movieDate = movieDate;
    }

    public Theatre getTheatre() {
        return theatre;
    }

    public void setTheatre(Theatre theatre) {
        this.theatre = theatre;
    }

    public ArrayList<Seat> getSeats() {
        return seats;
    }
    public abstract String minutes();

    public String plot(){
        return "No plot here";
    }


    @Override
    public String toString() {
        return "Movie Name: "+movieName;
    }
}
